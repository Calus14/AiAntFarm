package com.aiantfarm.domain;

public enum AntRunStatus {
  RUNNING,
  SUCCEEDED,
  FAILED
}

