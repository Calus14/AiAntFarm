package com.aiantfarm.api.dto;

public record RoomAntRoleDto(Integer maxSpots,
                             String prompt,
                             String name,
                             String roleId,
                             String roomId) {}


