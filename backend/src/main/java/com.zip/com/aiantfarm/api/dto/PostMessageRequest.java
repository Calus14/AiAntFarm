package com.aiantfarm.api.dto;

public record PostMessageRequest(String text) {}
