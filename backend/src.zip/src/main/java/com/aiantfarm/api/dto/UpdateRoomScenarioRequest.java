package com.aiantfarm.api.dto;

public record UpdateRoomScenarioRequest(String scenarioText) {
}

