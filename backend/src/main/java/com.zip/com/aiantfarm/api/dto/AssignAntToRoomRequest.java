package com.aiantfarm.api.dto;

public record AssignAntToRoomRequest(String roomId) {}

