package com.aiantfarm.api.dto;

/** Assign (or clear) a RoomAntRole for an existing AntRoomAssignment. */
public record AssignAntRoomRoleRequest(String roleId) {
}

